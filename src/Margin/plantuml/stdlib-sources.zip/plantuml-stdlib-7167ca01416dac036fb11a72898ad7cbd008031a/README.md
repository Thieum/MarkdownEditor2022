# `plantuml-stdlib`
Contains official Standard Library for PlantUML.
_See http://plantuml.com/stdlib for more information._

This Standard Library is included in official release of PlantUML.
Following the C convention for "C standard library" _(see https://en.wikipedia.org/wiki/C_standard_library)_.

<details>
<summary>List of current `stdlib` include on PlantUML</summary>

[![](https://img.plantuml.biz/plantuml/svg/SoWkIImgAStDuUKgBad9oKpYvN98pKi12W00)](https://editor.plantuml.com/uml/SoWkIImgAStDuUKgBad9oKpYvN98pKi12W00)

</details>

## Table of contents

  - [AdaML [adaml]](#adaml-adaml)
    - [What is AdaML](#what-is-adaml)
    - [Features](#features)
  - [Amazon Web Services](#amazon-web-services)
    - [AWS Icons](#aws-icons)
    - [AWS library [aws]](#aws-library-aws)
    - [Amazon Labs AWS Library [awslib]](#amazon-labs-aws-library-awslib)
  - [Azure library [azure]](#azure-library-azure)
  - [Bootstrap Icons [bootstrap]](#bootstrap-icons-bootstrap)
  - [C4 library (C4-PlantUML) [C4]](#c4-library-c4-plantuml-c4)
  - [Classy library [classy]](#classy-library-classy)
  - [Classy C4 library [classy-c4]](#classy-c4-library-classy-c4)
  - [Domain Story library (DomainStory-PlantUML) [DomainStory]](#domain-story-library-domainstory-plantuml-domainstory)
  - [Edgy Enterprise Design [edgy]](#edgy-enterprise-design-edgy)
    - [Facets](#facets)
    - [Elements](#elements)
    - [Links](#links)
    - [Concrete example of usage](#concrete-example-of-usage)
  - [EIP-PlantUML [eip]](#eip-plantuml-eip)
  - [Elastic library [elastic]](#elastic-library-elastic)
  - [Google Cloud Platform [gcp]](#google-cloud-platform-gcp)
  - [K8S [k8s]](#k8s-k8s)
  - [Google Material Icons [material, material2, material7]](#google-material-icons-material-material2-material7)
    - [(Old version) PNG sprites - compatibility mode [material, material2]](#old-version-png-sprites---compatibility-mode-material-material2)
      - [Notes](#notes)
    - [SVG sprites [material7, material7.4.47]](#svg-sprites-material7-material7447)
      - [Macros and predefined values via `!include <material7/common>`](#macros-and-predefined-values-via-include-material7common)
  - [Tupadr3 library [tupadr3]](#tupadr3-library-tupadr3)

## AdaML [adaml]

### What is AdaML
- UML tailored for Ada 2012 programming language
- A modeling language to draw UML diagrams, implemented in PlantUML
- An easy way to learn Ada through the use of UML and OOP concepts

### Features
- UML tailored to use and show particular Ada language characteristics
- Coherent set of functions to design software components for Ada
- Generates high quality drawings (ps, eps) easy to embedded in other docs
- Easy to learn by example, both AdaML and Ada language

Example of usage:
```plantuml
@startuml
!include <AdaML/AdaML>

actor User
agent String_Instrument
agent Screen
agent Touch_Screen
agent Microphone

begin_package_spec("Floyd_Tuner")

  subprogram("Main")

  package("View")
  package("Controller")
  package("Signal_Analyzer")
  package("Sample_Collector")

  depends("User", "Touch_Screen", "interacts >")
  depends("Main", "Controller", "starts >")
  depends("User", "Screen", "see")
  depends("User", "String_Instrument", "plays\n&\ntunes")

  depends("Touch_Screen", "Controller", "commands")

  depends("Controller", "Sample_Collector", "manages")
  depends("Controller", "Signal_Analyzer", "configures")
  depends("Controller", "View", "commands")

  depends("View", "Screen", "output >")
  depends("View", "Signal_Analyzer", "read\nresults >")
  depends("Signal_Analyzer", "Sample_Collector", "read\nsamples >")
  depends("Sample_Collector", "Microphone", "ADC")

  depends("String_Instrument", "Microphone", "captures <")

end()
@enduml
```

This example renders the following image:

[![AdaML example](https://img.plantuml.biz/plantuml/svg/VLFBQiCm4BphArGVYWE5_a082Ic5GdrAsbF0AFBM4PLNGWzA-lMLb9SjExtOxEpCQdPaBwrZnlbEaWU1NFe6w7pLiEhzEJqNX33kbA4V5WnXBQ2Z6sS4jlKRMcTy5v0BpWq0dekjylnG3w1ASAFqGI4GieTMOAqP_mwzschWPV4grR6fjnx153D2ABL-hurg3UlAec82J-XPL1QV0du2r4FM2frHKgO1FNmZMcIoNeN7yNVKP9sMKA-ZBgvwEgK13TZOieYB5q-qw2yKQu4EJCZ6qaMQTnKafu7GCnEg5FE8Unb-6si1xb3or2Ee9JlQ7Jxkq8NOR6Ozjpnqn5NNiS3BH4FIA9o01LK8pWvjPh8iy7GSVedMc_-5wKxlcxkqRpifxxHtUQvNtjY70TRiCDZmSdmV4_of14upREgCPqm8Rfz-h5OlwsoloSiTYZZJBgP7vr4RPEMCBCCh_hf_)](https://editor.plantuml.com/uml/VLFBQiCm4BphArGVYWE5_a082Ic5GdrAsbF0AFBM4PLNGWzA-lMLb9SjExtOxEpCQdPaBwrZnlbEaWU1NFe6w7pLiEhzEJqNX33kbA4V5WnXBQ2Z6sS4jlKRMcTy5v0BpWq0dekjylnG3w1ASAFqGI4GieTMOAqP_mwzschWPV4grR6fjnx153D2ABL-hurg3UlAec82J-XPL1QV0du2r4FM2frHKgO1FNmZMcIoNeN7yNVKP9sMKA-ZBgvwEgK13TZOieYB5q-qw2yKQu4EJCZ6qaMQTnKafu7GCnEg5FE8Unb-6si1xb3or2Ee9JlQ7Jxkq8NOR6Ozjpnqn5NNiS3BH4FIA9o01LK8pWvjPh8iy7GSVedMc_-5wKxlcxkqRpifxxHtUQvNtjY70TRiCDZmSdmV4_of14upREgCPqm8Rfz-h5OlwsoloSiTYZZJBgP7vr4RPEMCBCCh_hf_)

## ArchiMate

### What is ArchiMate
[ArchiMate](https://www.opengroup.org/archimate-forum/archimate-overview) is an enterprise architecture modeling language that supports the description, analysis, and visualization of architecture across business domains.

ArchiMate offers a common language for describing the construction and operation of business processes, organizational structures, information flows, IT systems, and technical infrastructure. This is just like an architectural drawing in classical building where the architecture describes the various aspects of the construction and use of a building. This insight helps the different stakeholders to design, assess, and communicate the consequences of decisions and changes within and between these business domains.

### Features
- Functions to draw all ArchiMate 3.2 types and relationships
- Support for regular shapes (rectangles with graphical stereotype icons) and some special shapes (stakeholders, roles, actors, value, meaning)
- Allows arbitrary nesting of concepts

<details>
<summary>Example of usage</summary>

```plantuml
@startuml Internet Browser Sample

!include <archimate/Archimate>
'!theme archimate-alternate from <archimate/themes>
'!theme archimate-handwriting from <archimate/themes>
'!theme archimate-lowsaturation from <archimate/themes>
'!theme archimate-saturated from <archimate/themes>
'!theme archimate-standard from <archimate/themes>

title Archimate Sample - Internet Browser

'LAYOUT_AS_SKETCH()
'LAYOUT_LEFT_RIGHT()
'LAYOUT_TOP_DOWN()

Business_Object(businessObject, "A Business Object")
Business_Process(someBusinessProcess,"Some Business Process")
Business_Service(itSupportService, "IT Support for Business (Application Service)")

Application_DataObject(dataObject, "Web Page Data \n 'on the fly'")
Application_Function(webpageBehaviour, "Web page behavior")
Application_Component(ActivePartWebPage, "Active Part of the web page \n 'on the fly'")

Technology_Artifact(inMemoryItem,"in memory / 'on the fly' html/javascript")
Technology_Service(internetBrowser, "Internet Browser Generic & Plugin")
Technology_Service(internetBrowserPlugin, "Some Internet Browser Plugin")
Technology_Service(webServer, "Some web server")

Rel_Flow_Left(someBusinessProcess, businessObject, "")
Rel_Serving_Up(itSupportService, someBusinessProcess, "")
Rel_Specialization_Up(webpageBehaviour, itSupportService, "")
Rel_Flow_Right(dataObject, webpageBehaviour, "")
Rel_Specialization_Up(dataObject, businessObject, "")
Rel_Assignment_Left(ActivePartWebPage, webpageBehaviour, "")
Rel_Specialization_Up(inMemoryItem, dataObject, "")
Rel_Realization_Up(inMemoryItem, ActivePartWebPage, "")
Rel_Specialization_Right(inMemoryItem,internetBrowser, "")
Rel_Serving_Up(internetBrowser, webpageBehaviour, "")
Rel_Serving_Up(internetBrowserPlugin, webpageBehaviour, "")
Rel_Aggregation_Right(internetBrowser, internetBrowserPlugin, "")
Rel_Access_Up(webServer, inMemoryItem, "")
Rel_Serving_Up(webServer, internetBrowser, "")

@enduml
```
</details>

This example renders the following image:
![Archimate Example](https://raw.githubusercontent.com/plantuml-stdlib/Archimate-PlantUML/refs/heads/master/images/Archimate%20Sample%20-%20Internet%20Browser.png)

For more information: https://github.com/plantuml-stdlib/Archimate-PlantUML

## Amazon Web Services

### AWS Icons

PlantUML images, sprites, macros, and other includes for Amazon Web Services (AWS) services and resources. Used to create PlantUML diagrams with AWS components. All elements are generated from the official [AWS Architecture Icons](https://aws.amazon.com/architecture/icons/) and when combined with [PlantUML](http://plantuml.com/) and the [C4 model](https://c4model.com/), are a great way to communicate your design, deployment, and topology as code.

Besides usage as custom sprites on PlantUML components, different types of diagrams can quickly and easily be created with the icons.

More info on [awslabs github account](https://github.com/awslabs/aws-icons-for-plantuml).

### AWS library [aws]

The AWS library consists of Amazon AWS icons, it provides icons of two different sizes.

Use it by including the file that contains the sprite, eg: `!include <aws/Storage/AmazonS3/AmazonS3>`.
When imported, you can use the sprite as normally you would, using `<$sprite_name>`.

You may also include the `common.puml` file, eg: `!include <aws/common>`, which contains helper macros defined.
With the `common.puml` imported, you can use the `NAME_OF_SPRITE(parameters...)` macro.

Example of usage:
```plantuml
@startuml
!include <aws/common>
!include <aws/Storage/AmazonS3/AmazonS3>
!include <aws/Storage/AmazonS3/bucket/bucket>

AMAZONS3(s3_internal)
AMAZONS3(s3_partner,"Vendor's S3")
s3_internal <- s3_partner
@enduml
```

This example renders the following image:

![Example](http://www.plantuml.com/plantuml/png/SoWkIImgAStDuLBCp4lEAKr9LR19B2_MJyxFpStFiqCJ3Ix9BqfCJzLtp4sioiyBDeOp22fCAatEJYs1KdPSN8w-Zb7-Vi766iN6yPbv9Qb5UOavcYYY1K1tvQKMwIY5fUQbv1Uf5oi46ojfSY6fLx3HLK0ev780gWDw1000 "Example")

### Amazon Labs AWS Library [awslib]

_Todo: TBC..._

## Azure library [azure]

The Azure library consists of Microsoft Azure icons.

Use it by including the file that contains the sprite, eg: `!include <azure/Analytics/AzureEventHub.puml>`.
When imported, you can use the sprite as normally you would, using `<$sprite_name>`.

You may also include the `AzureCommon.puml` file, eg: `!include <azure/AzureCommon.puml>`, which contains helper macros defined.
With the `azure/AzureCommon.puml` imported, you can use the `NAME_OF_SPRITE(parameters...)` macro.

Example of usage:
```plantuml
@startuml
!include <azure/AzureCommon>
!include <azure/Analytics/AzureEventHub>
!include <azure/Analytics/AzureStreamAnalyticsJob>
!include <azure/Databases/AzureCosmosDb>

left to right direction

agent "Device Simulator" as devices #fff
AzureEventHub(fareDataEventHub, "Fare Data", "PK: Medallion HackLicense VendorId; 3 TUs")
AzureEventHub(tripDataEventHub, "Trip Data", "PK: Medallion HackLicense VendorId; 3 TUs")
AzureStreamAnalyticsJob(streamAnalytics, "Stream Processing", "6 SUs")
AzureCosmosDb(outputCosmosDb, "Output Database", "1,000 RUs")

devices --> fareDataEventHub
devices --> tripDataEventHub
fareDataEventHub --> streamAnalytics
tripDataEventHub --> streamAnalytics
streamAnalytics --> outputCosmosDb
@enduml
```

This example renders the following image:

![Example](http://www.plantuml.com/plantuml/proxy?idx=0&src=https%3A%2F%2Fraw.githubusercontent.com%2FRicardoNiepel%2FAzure-PlantUML%2Fmaster%2Fsamples%2FBasic%2520usage%2520-%2520Stream%2520processing%2520with%2520Azure%2520Stream%2520Analytics.puml "Example")

## Bootstrap Icons [bootstrap]

This library consists of a free Bootstrap Icons style icons from Bootstrap. See the entire collection or search via a filter on the [Bootstrap Icons website](https://icons.getbootstrap.com/#search).

Use it by including the file that contains all the sprites: `!include <bootstrap/bootstrap>`.
When imported, you can use the sprite as normally you would, using `<$bi-sprite-name>`.
Notice that this library requires an `bi-` preffix on sprites names, this is to avoid clash of names if multiple sprites have the same name on different libraries. `bi` stands for Bootstrap Icon and this name is also used in the Bootstrap framework.

Example of usage:
```plantuml
@startuml
skinparam UsecaseBackgroundColor white
!include <bootstrap/bootstrap>

usecase a as "<$bi-globe>\nbi-globe"
usecase b as "<$bi-globe,scale=2.5>"
usecase c as "<$bi-globe{scale=2.5}>" #line:red

usecase d as "<$bi-bootstrap-fill>"
usecase e as "<$bi-bootstrap-fill{scale=2.5,color=blue}>"
usecase f as "<$bi-bootstrap-fill,scale=2.5,color=#00f>"
@enduml
```

This example renders the following image:

[![bootstrap Example](https://img.plantuml.biz/plantuml/svg/TP3B2i8m44NtXVn3h2vR5S6Ds53q6zovcIHJ3HsJaWSkn7zN4TjIS7SNvyoTcJf4y37TY6MXDRO33pT-2gWWu05KU_4kMNrqv3o_Nqr4bisCLPGqyhrqBeReeLlrIR2CPUdhS-0GUBvVI5DUo4aKP_kB-K392LK41OJLPhaL8qfDg4TFFKNEvsGixZpgSRqUb7w_iZ54uxdu3neA2lKvlvAKy3bMctzgCLNdwtNpCMkq-lth5m00 "bootstrap Example")](https://editor.plantuml.com/uml/TP3B2i8m44NtXVn3h2vR5S6Ds53q6zovcIHJ3HsJaWSkn7zN4TjIS7SNvyoTcJf4y37TY6MXDRO33pT-2gWWu05KU_4kMNrqv3o_Nqr4bisCLPGqyhrqBeReeLlrIR2CPUdhS-0GUBvVI5DUo4aKP_kB-K392LK41OJLPhaL8qfDg4TFFKNEvsGixZpgSRqUb7w_iZ54uxdu3neA2lKvlvAKy3bMctzgCLNdwtNpCMkq-lth5m00)

## C4 library (C4-PlantUML) [C4]

<!-- start C4 section -->
![name: C4](https://img.shields.io/badge/name-C4-black)
![display_name: C4 (C4-PlantUML)](https://img.shields.io/badge/display__name-C4_(C4--PlantUML)-black)
[![version: 2.14.0][Version Badge]][Version Link]
![license: MIT](https://img.shields.io/badge/license-MIT-green)
![author: Ricardo Niepel, kirchsth and contributors](https://img.shields.io/badge/author-Ricardo_Niepel,_kirchsth_and_contributors-black)  
[![all properties see: ./stdlib/C4/README.md][See Badge]][See Link]  

[Version Badge]: https://img.shields.io/badge/version-2.14.0-blue
[Version Link]: https://github.com/plantuml-stdlib/C4-PlantUML/tree/release/v2.14.0
[See Badge]: https://img.shields.io/badge/all_stdlib_specific_properties_see-./stdlib/C4/README.md-blue
[See Link]: ./stdlib/C4/README.md
<!-- end C4 section -->

The C4 library enables a simple way of describing and communicate software architectures with an intuitive language.

It is the PlantUML integrated version of [C4-PlantUML](https://github.com/plantuml-stdlib/C4-PlantUML) and has the big advantage that it can be used without additional external includes.
(E.g. container diagrams can be drawn with `!include <C4/C4_Container>` and no `!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml` is required.)

Example of usage:

```plantuml
@startuml
!include <C4/C4_Container>
LAYOUT_LEFT_RIGHT()

Person(admin, "Administrator")
System_Boundary(c1, "Sample System") {
    Container(web_app, "Web Application", "C#, ASP.NET Core 2.1 MVC", "Allows users to compare multiple Twitter timelines")
}
System(twitter, "Twitter")

Rel(admin, web_app, "Uses", "HTTPS")
Rel(web_app, twitter, "Gets tweets from", "HTTPS")

SHOW_LEGEND()
@enduml
```

This example renders the following image:

[![Example](https://www.plantuml.com/plantuml/svg/JL1TQy9047o_Nx5DNn8GYyN7KanJgmMhOivAdyAPRE7WFiBT1f7I_zvDjTfxMUvcPcTk9f5KeCuQSQDTRRe6uQ4OtnNZgl2Eb7OO7iKY_rXjPRMOliXgypgRopGJOeqXUfUgncetW2JlfuuK5FcGPA8yHa9RFVdEDIeSqth4f5BPrY2Si2I3Bm5yBaxf0VULQbjcxd0FUTiQNIlItYNyLDmE82_Nm-LKiYGWt0z7yFPUz5XkZ3z4w2A62EIXzhPLJB6T8TrRoeCcmW2aBHhsYXpn-nmofHF8Uyuq1iK6pT_dhh6saPKyvrAkooJx9LtGwvePKkGhzkCpUFjV8ihvQiTTpgRBP-vnWgxX-dy0)](https://www.plantuml.com/plantuml/uml/JL1TQy9047o_Nx5DNn8GYyN7KanJgmMhOivAdyAPRE7WFiBT1f7I_zvDjTfxMUvcPcTk9f5KeCuQSQDTRRe6uQ4OtnNZgl2Eb7OO7iKY_rXjPRMOliXgypgRopGJOeqXUfUgncetW2JlfuuK5FcGPA8yHa9RFVdEDIeSqth4f5BPrY2Si2I3Bm5yBaxf0VULQbjcxd0FUTiQNIlItYNyLDmE82_Nm-LKiYGWt0z7yFPUz5XkZ3z4w2A62EIXzhPLJB6T8TrRoeCcmW2aBHhsYXpn-nmofHF8Uyuq1iK6pT_dhh6saPKyvrAkooJx9LtGwvePKkGhzkCpUFjV8ihvQiTTpgRBP-vnWgxX-dy0)

## Classy library [classy]

The Classy library allows for using an Object Oriented approach to diagramming
in PlantUML.

That is to say that it allows you to define and instantiate your own classes as
well as allow you to call methods defined on those classes. You can also inherit
from one or more classes where desired.

Use it by including the file that contains the Classy class that you want to use
within your diagram. Alternatively, if you want to define your own type, you can
just include the `core.puml` file, eg: `!include <classy/core>`, which contains
all of the necessary functions.

Example of usage:
```plantuml
@startuml
!include <classy/core>
$class(HelloWorld)
  $classVar(msg, string, "Hello World!")
  $classMethod(getMessage)
    !function HelloWorld__getMessage($this)
      !return $getInstanceVar($this, 'msg')
    !endfunction
  $endclassMethod(getMessage)
  $classMethod(setMessage)
    !function HelloWorld__setMessage($this, $args)
      $setInstanceVar($this, 'msg', $call($args, 'each'))
      !return $this
    !endfunction
  $endclassMethod(setMessage)
$endclass(HelloWorld)
!$hello = $new(HelloWorld)
Alice -> Bob : $call($hello, 'getMessage')
$call($hello, 'setMessage', array($new(array), '2nd message!'), $void=%true())
Alice -> Bob : $call($hello, 'getMessage')
@enduml
```

This example renders the following image:

![Example](http://www.plantuml.com/plantuml/png/SoWkIImgAStDuNBAJrBGjLDmpCbCJbMmKl18pSd9LmZFByf9KKINCyfBKSXDBIvEJ4zLKEHoICrB0He00000)

## Classy C4 library [classy-c4]

The Classy C4 library combines the Classy and C4 libraries by defining Classy
classes that wrap the C4 macros.

Example of usage:
```plantuml
@startuml
!include <classy-c4/container>
!include <classy-c4/person>
!include <classy-c4/system>

!$system = $new(System)

$call($system, 'setName', 'Label', $void=%true())
$call($system, 'setDescription', 'Optional Description', $void=%true())
!$person = $new(Person)
$call($person, 'setName', 'Label', $void=%true())
$call($person, 'setDescription', 'Optional Description', $void=%true())
!$container = $new(Container)
$call($container, 'setName', 'Label', $void=%true())
$call($container, 'setDescription', 'Optional Description', $void=%true())
$call($container, 'setTechnology', 'Technology', $void=%true())
!$personAlias = $call($person, 'render')
!$containerAlias = $call($container, 'render')
$call($system, 'render', $void=%true())
Rel($personAlias, $containerAlias, "Label", "Optional Technology")
@enduml
```

This example renders the following image:

![Example](http://www.plantuml.com/plantuml/png/ZOvFIyGm4CNl-HIrfowupMLFdbQgjnKN_vnbcWxRm6GICXDalxtPWaKHnTDxCypxpTkBGjOIg1bsR_U40Ld5N7bsL2PiPjKaDzPcUEzFNkSo5i7i8YkozYu6cmZuaj-AJkH7E-osnylgzU5W0uXYjfKyr0HunjodUclC4RD4xj8Yj-H1hfls02DIMyrZKXyPgBb3STalKxinAwHpd-v7z0NTp97YwVm7wFaiYg6JHVxxtJmXVI-yjlWTyQNEnkoHfnBe0m00)

## Domain Story library (DomainStory-PlantUML) [DomainStory]

This library provides a set of macros to easily describe and document a domain story which was developed in
a [Domain Storytelling](http://www.domainstorytelling.org) workshop.

For more usage instructions see [DomainStory-PlantUML](https://github.com/johthor/DomainStory-PlantUML).

Example of usage:

```plantuml
@startuml
!include <DomainStory/domainStory>

Boundary(System) {
  Person(Alice)
  Conversation(weather)
  Person(Bob)
}
activity(1, Alice, talks about the, weather, with, Bob)
@enduml
```

This example renders the following image:

![Example](http://www.plantuml.com/plantuml/png/JSx1IWGn30RWUv-YtcPWdEBLqxfwL5XOV81C9zXg9rdQlxiCuhlR7GGtf_0bVyYkW3BgainT59_gp3O0f_BeNARB-14HwbGBPwy25enU5_Uf0K6pUz65eXoXURq_91AylxswAxdvVpAUhjVDNglCbDVkk1RmqjjlOriTE1ULxYb5p_qcpohdXeJO_CA4mBc_tTthr9iVOyWZdYFMxc6mMtwmeFHLB4rQOH4Q_ELR4n46kqLtB7DxwHS0
 "Example")

## Edgy Enterprise Design [edgy]
Edgy is an Open Source tool for collaborative Enterprise Design. The library is an adaption of the EDGY Tools for PlantUML usage.

The Sprites are based on the [Enterprise Design with EDGY](https://www.enterprise.design/). They'll be rendered as SVG sprites, so you need a quite actual PlantUML distribution.

Use it by including the file that contains the sprite, eg: `!include <edgy/edgy>`.
There are two visual sets:
* `!include <edgy/edgy>` is the visualization according to the open source set of edgy.
* `!include <edgy/edgy2>` is the one which describes with stereotypes what kind of element it is. If you have color blinded people, this one could be the better one.
All procedures are compatible between both sets. So you can begin with one and switch to the other just to have a look which of the one fits visually the best.

The library is not complete yet, but it's a good start.

In general, the procedures for elements and facets do have the form of
```plantuml
$elementorfacet("label", alias, lighterColor)
```
* ```"label"``` is the name of the element or facet. It is mandatory.
* ```alias``` is used for linking elements and facets. It is optional.
* ```lighterColor``` is used as a boolean value (!) to use a lighter color for the element or facet. It is optional.
  * Facets are drawn with lighter colors than Elements as default.
  * ```0``` is false. Any other value is true.  Or use ```%true()``` and ```%false()``` _(see [Boolean expression in Preprocessing](https://plantuml.com/preprocessing#55eb000153a81c72))_.

### Facets
Facets do have the edgy facet name followed with ```Facet``` as tail, to distinguish them from elements.<br/>
The following facets are implemented: ```$baseFacet```, ```$identityFacet```, ```$brandFacet```, ```$experienceFacet```, ```$productFacet```, ```$architectureFacet```, ```$organisationFacet```

### Elements
Elements do have the edgy element name.<br/>
The following elements are implemented:
- Base: ```$people```, ```$outcome```, ```$activity```, ```$object```
- Identity: ```$purpose```, ```$story```, ```$content```
- Brand: ```$brand```
- Experience: ```$task```, ```$channel```, ```$journey```
- Product: ```$product```
- Architecture: ```$capability```, ```$asset```, ```$process```
- Organisation: ```$organisation```

Elements can be nested into facets:
```plantuml
$architectureFacet("Architecture") {
  $capability("Capability")
}
```

However, it is also possible to nest elements if needed:
```plantuml
$capability("Customer Interaction") {
    $capability("Passenger Services", pass, 1) {
        $capability("Passenger Information", info)
    }
}
```

### Links
Links do have the form of:
```plantuml
$link(fromAlias, toAlias, "label")
```
* ```fromAlias``` is the starting element or facet. It is mandatory.
* ```toAlias``` is the target element or facet. It is mandatory.
* ```"label"``` is a label written on the connection. This is optional.

There are only three sort of links:
* ```$link``` is a unidirectional link between elements or facets.
* ```$flow``` is a directed flow between elements or facets.
* ```$tree``` is a hierarchical representation of elements as a tree relationship.

Generally, all links do have the possibility to give the rendere a hint in which direction the link should be drawn. This is done by adding ```Up```, ```Down```, ```Left```, ```Right``` as a tail to the link name (e.g. ```$linkUp```, ```$linkDown```, ```$linkLeft```, ```$linkRight```).

### Concrete example of usage
```plantuml
@startuml
!include <edgy/edgy>
$identityFacet("This is the Identity facet", identity) {
  $content(" This is the Content element", content)
  $purpose("This is the Purpose element", purpose)
  $story("This is the Story element", story)
}
$link(content, purpose)
$link(content, story)
$link(purpose, story)
@enduml
```

[![](https://img.plantuml.biz/plantuml/svg/NP3H2e8m58Rl1T_XDBnG27g12248l0lg1MGxvMXESSSBYTwzeviqWx71_t_V3blfg1veR4sQxBILPbG8HrJFwJ1lfpJ9j49BcgPBBP5oSM-q0rxK85IXWiVSYJsiR07lD078P6U9arn0h9rz2cYmvPEzm1MBr8z3tpdSZhhwC782vXr7tJ1jZTiSHVo2CFtXDnbjNtaO6j_qLwoAZmFsYqkqYd_k2m00)](https://editor.plantuml.com/uml/NP3H2e8m58Rl1T_XDBnG27g12248l0lg1MGxvMXESSSBYTwzeviqWx71_t_V3blfg1veR4sQxBILPbG8HrJFwJ1lfpJ9j49BcgPBBP5oSM-q0rxK85IXWiVSYJsiR07lD078P6U9arn0h9rz2cYmvPEzm1MBr8z3tpdSZhhwC782vXr7tJ1jZTiSHVo2CFtXDnbjNtaO6j_qLwoAZmFsYqkqYd_k2m00)

## EIP-PlantUML [eip]

EIP-PlantUML provides [Enterprise Integrations Patterns](https://www.enterpriseintegrationpatterns.com/) elements to [PlantUML](http://plantuml.com/) to provide easy support of designing EIP architectures for both, up-front design as well as development-time automated documentation generation.
Example of usage:
```plantuml
@startuml
!include <eip/EIP-PlantUML>
!theme mars
skinparam linetype ortho
left to right direction
folder "RabbitMQ" #line.dashed {
    Message(msg0, Message)
    Message(msg1, Message)
    Message(msg2, Message)
    MsgChannel(ch0, inQueue)
    MsgChannel(ch1, outQueue)
    MsgChannel(ch2, outQueue)
    MessageRouter(rt0, Router)
}
Send(msg0, ch0)
Send(ch0, rt0)
Send(rt0, msg1)
Send(rt0, msg2)
Send(msg1, ch1)
Send(msg2, ch2)
@enduml
```
This example renders the following image:
![Example](https://cdn-0.plantuml.com/plantuml/png/VP3FIiD04CRlFiMsNbgmYURegI0U10DjnGVOPAVPnVqJPcOH4T_TtOrY2x5p29dVzsM-cMo99N9qzcfXV6-Z0g6PHxglQvJlrM1OnouIO1yyW-Ug3wuUhVJvcmsnigQh7vzscrrch-rpxQJnjJB4PxWQSuP8jM0D3eIJIAMdD-D7YT89QppmnmWY8EjGH0j75Xm4ca6pK0QXPnDyqOx1Aa2nFCYkCzpkb-8wJwYK90rAV6PJgHQ8v00hHyFjpM-tdfFlBilDd4p3WvRUWrtrEeqtVXyX_cT80I7o9KSpwvXI3qa1N26ddEbzidoLvmjuzNDZscJznyfUoAUeZCW7px3cX4t_9ErzpfhCac-R-kZiDm00)

## Elastic library [elastic]

The Elastic library consists of [Elastic](https://www.elastic.co) icons.
It is similar in use to the AWS and Azure libraries (it used the same tool to create them).

Use it by including the file that contains the sprite, eg: `!include <elastic/elasticsearch/elasticsearch.puml>`.
When imported, you can use the sprite as normally you would, using `<$sprite_name>`.

You may also include the `common.puml` file, eg: `!include <elastic/common>`, which contains helper macros defined.
With the `common.puml` imported, you can use the `NAME_OF_SPRITE(parameters...)` macro.

Example of usage:
```plantuml
@startuml
!include <elastic/common>
!include <elastic/elasticsearch/elasticsearch>
!include <elastic/logstash/logstash>
!include <elastic/kibana/kibana>

ELASTICSEARCH(ElasticSearch, "Search and Analyze",database)
LOGSTASH(Logstash, "Parse and Transform",node)
KIBANA(Kibana, "Visualize",agent)
Logstash -right-> ElasticSearch: Transformed Data
ElasticSearch -right-> Kibana: Data to View
@enduml
```

This example renders the following image:
![Example](http://www.plantuml.com/plantuml/png/TOxFQiCm38VlUGejfnHITYyZrEl2MXgsCOVUrLXBpFm7R8UnFVrI9oNa41yi6N-VVjhxW2xqMYKmd0Tf6jKBWYTIw8Di7XkhjJN5okzKFQ5hkkLhJL6szG5zTszMmMzvHODJAP98bHNZzUd0I_PvE6RbIFAObqCwDe1603EeVlyepGK6lAAdJVIhzrTUCtxCgYbyi3xGUOfIxT3uB-jqcXih9kLyUcPlB3l7DGRy8dsFIjvcOqicR21YyRfFXQsJRHUs1InMtCq99E050qPhmSpgcBYB70GB5qa_IR8d8tgj_W40)

## Google Cloud Platform [gcp]

```plantuml
@startuml
!include <gcp/GCPCommon>
!include <gcp/Compute/Cloud_Functions>
!include <gcp/Networking/Cloud_Firewall_Rules>
!include <gcp/Compute/Compute_Engine>
!include <gcp/Storage/Cloud_Storage>

Cloud_Functions(Cloud_FunctionsStart, "Start Server", "Cloud Functions")
Cloud_Functions(Cloud_FunctionsStop, "Stop Server", "Cloud Functions")
Cloud_Functions(Cloud_FunctionAdd, "Add a Friend", "Cloud Functions")
Compute_Engine(Compute_Engine, "MineCraft Server", "Compute Engine")
Cloud_Storage(Cloud_Storage, "MineCraft Backups", "Cloud Storage")
Cloud_Firewall_Rules(Cloud_Firewall_Rules_Starter,"Minecraft Backups", "Cloud Firewall Rules")
Cloud_Firewall_Rules(Cloud_Firewall_Rules_Friend,"Minecraft Backups", "Cloud Firewall Rules")
@enduml
```
This example renders the following image:

![Example](http://cdn-0.plantuml.com/plantuml/png/lP9FJm8n4CNlV8hAQKs0tZsX6_4YXaWyR-fsN1hwPpETojTttBgQ4X9335wOFFBUxz4Nbf4KKd9sScLyQvC6iIFguusKg0wBpj0klQO8s0PFu6dH1YThL747sXclvSOgJo_hnxbXHvm_r1lfL2H0gKqaoReEpWM_w2zNmWrz8f2r3Katg-HRCkoxPEKJq27WtlXkR3K81sLjyvmin7zvRRxDlU-CXqisRYcWwiPzlrGkd4oEHg-Ez9OKqanCXoksWE-0KzQ3JNpRfjU_WqBFkS_p1yojrfpYJw742WruVPfIZbkLaXDhFhpWM_6aR1BPn91YhwfG1U9EjVlKnvzVaaqZulZFLPtwiXa61fmDtFOqTuo88N8MFezr7dt9YUJi1m00)

## K8S [k8s]

These are the PlantUML sprites, macros and stereotypes for creating PlantUML diagrams with the Kubernetes components. The official Kubernetes Icons Set (where this work is based) can be found [here](https://github.com/kubernetes/community/tree/master/icons).
This stdlib is heavily influenced by the awesome work from Ricardo Niepel on [Azure-PlantUML](https://github.com/plantuml-stdlib/Azure-PlantUML).

Example of usage:
```plantuml
@startuml
!include <k8s/Common>
!include <k8s/Simplified>
!include <k8s/OSS/all>

footer Kubernetes Plant-UML
scale max 1024 width
skinparam {
    nodesep 10
    ranksep 10
}

actor "User" as userAlias
left to right direction
Cluster_Boundary(cluster, "Kubernetes Cluster") {
    Namespace_Boundary(ns, "Web") {
        KubernetesSvc(svc, "service", "")
        KubernetesPod(pod1, "web-pod1", "")
        KubernetesPod(pod2, "web-pod2", "")
    }
}
Rel(userAlias,svc,"get HTTP/1.1 index.html", "1")
Rel(svc,pod1,"load Balances to Pods", "2")
Rel(svc,pod2,"load Balances to Pods", "2")
Rel_U(pod1, svc, "serves content", "3")
Rel(svc, userAlias, "return content to", "4")
@enduml
```
This example renders the following image:

![Example](http://cdn-0.plantuml.com/plantuml/png/ZPDFYzim4CNl-HIpFcLX4zVk7afFszrBeNyQcWqzXeaqYKNqnqYZ9ANiTw_aDR6RKXeTZ9ZtUyFe3Nu8Z9wZqPCRILjb2VRl0ZJCRNXVbXwFyvtY9cvY82-SPR8y5ywKKc10LkK-RiXROWgpXKRBgo-VIuE1oPTI1Pv0EZVA2XqbHQzpzv5d_UICSNRUvW7-Yrgc4r_5BfLfjTegal_6losNvQUpPNaGrw8BD-gwTOx9mw12Ze5dAOTE3m8rWS4JL6_gUpWgoSshi5UsHOy6VasWFzP92jGcz5poQFUZqaltHS7EGx4Av0l007av7xJ2qAcQjWpimAjTmo2L9y7AsKvxqZ7lPlteefNeVqx5Q-4EYj4JUggu7Sts5Gs55WKDNXkIxGTj1gu_VyGw3GUHk43-e0GLwLhSNj93ijFMoIenHzhCylKQlXxu-e9_cGpVxwIdvwJkybJ5ZXW-FZylocfUWRAIJlE6ZSvDgkBsxCfiDrUX7KfuH8rMKCWXfn52nkk_yVewVBtgtppabDZ-NylisulMmxgJw8cZjpsUrvuTzydnG5P6ety3)

## Google Material Icons [material, material2, material7]

### (Old version) PNG sprites - compatibility mode [material, material2]

This library consists of a free Material style icons from Google and other artists based on v2.1.19.

The old library is kept for compatibility reasons, but new projects should use the new SVG based library described below.

The library can be included via **`!include <material/...>`** (e.g. `!include <material/folder_move>`).
(Theoretically can it be included via `!include <material2/...>` or `!include <material2.1.19/...>` too, but no v2.* updates are planned anymore.)
When imported, you can use the sprite as normally you would, using `<$ma_sprite_name>` (e.g. `<$ma_folder_move>`).
Notice that this library requires an `ma_` prefix on sprites names, this is to avoid clash of names if multiple sprites have the same name on different libraries.

**Example of usage:**

```plantuml
@startuml
' To import the sprite file you DON'T need to place a prefix!
!include <material/folder_move>

usecase a as "<$ma_folder_move>\nmove a file into a folder UC"
usecase c as "<$ma_folder_move{scale=2.5,color=#00f}>\nanother move file into a folder UC" #line:red

' The macro cannot be used without !include <material/common>
' MA_FOLDER_MOVE(Red, 1, dir, rectangle, "A label")
@enduml
```

This example renders the following image:

[![Sprite example - open link](https://www.plantuml.com/plantuml/svg/TP1FIyD04CNl-HIlgL25eFNWHThIOkl9MYZLan2cknExCBiJDXl_87vt4mhYePxcyllDuxrvaoYcraismaxXVAqn8HqOJHrTObHE69_QOhbv7EqGc2sIeXOo348TkN8VWspWWf7MCYQU4aT7SbMfM8wbrpUUPLdRiA6cLwX1FZdpLFu5Na9_GCSy5vA2S0JmT9V_wkQa_jKO4fwEBsyAew9nEXoFg-yPA6XN9Q9d_lcCeRZ0jv5jrazmO7WoKM4eT3BsZ2xQujsbWxO99teQzLx3hBFNY_9-yx1SRSlrvdbrlcLRuBg0TR50P9Cel0eNo1SGshFa5zcSWssz_000 "Sprite example")](https://www.plantuml.com/plantuml/uml/TP1FIyD04CNl-HIlgL25eFNWHThIOkl9MYZLan2cknExCBiJDXl_87vt4mhYePxcyllDuxrvaoYcraismaxXVAqn8HqOJHrTObHE69_QOhbv7EqGc2sIeXOo348TkN8VWspWWf7MCYQU4aT7SbMfM8wbrpUUPLdRiA6cLwX1FZdpLFu5Na9_GCSy5vA2S0JmT9V_wkQa_jKO4fwEBsyAew9nEXoFg-yPA6XN9Q9d_lcCeRZ0jv5jrazmO7WoKM4eT3BsZ2xQujsbWxO99teQzLx3hBFNY_9-yx1SRSlrvdbrlcLRuBg0TR50P9Cel0eNo1SGshFa5zcSWssz_000)

You may also include the `common.puml` file, e.g. `!include <material/common>`, which contains helper macros. With the `common.puml` imported, you can use the `MA_NAME_OF_SPRITE(parameters...)` macro, note again the use of the prefix `MA_`. Following calls are supported:

- `MA_SPRITE_NAME(_color)`
- `MA_SPRITE_NAME(_color, _scale)`
- `MA_SPRITE_NAME(_color, _scale, _alias)`
- `MA_SPRITE_NAME(_color, _scale, _alias, _shape)`
- `MA_SPRITE_NAME(_color, _scale, _alias, _shape, _label)`

**Example of usage:**

```plantuml
@startuml
!include <material/common>
' To import the sprite file you DON'T need to place a prefix!
!include <material/folder_move>

MA_FOLDER_MOVE(Red, 1, dir, rectangle, "A label")
@enduml
```

This example renders the following image:

[![Macro example - open link](http://www.plantuml.com/plantuml/svg/PSn12i8m40NGVK_nsqqL0k9U2eNMbRLGYjiIawa69faGKz7RUm3V0LxfWk7D4avUPqfEyy68znAQeiOiS3vAoiXFmYicbmchOy9NDdJZjPuHY2oo8B8s18sOQ7MViYZ_urNOKbgylAafYg5TpkEbwwTb66_zRYAhS5ImBYaaCbc71vD2rOBrdRZQ_m00 "Macro example")](http://www.plantuml.com/plantuml/uml/PSn12i8m40NGVK_nsqqL0k9U2eNMbRLGYjiIawa69faGKz7RUm3V0LxfWk7D4avUPqfEyy68znAQeiOiS3vAoiXFmYicbmchOy9NDdJZjPuHY2oo8B8s18sOQ7MViYZ_urNOKbgylAafYg5TpkEbwwTb66_zRYAhS5ImBYaaCbc71vD2rOBrdRZQ_m00)

#### Notes

When mixing sprites macros with other elements you may get a syntax error if, for example, trying to add a rectangle along with classes.
In those cases, add `{` and `}` after the macro to create the empty rectangle.

**Example of usage:**

```plantuml
@startuml
!include <material/common>
' To import the sprite file you DON'T need to place a prefix!
!include <material/folder_move>

MA_FOLDER_MOVE(Red, 1, dir, rectangle, "A label") {
}

class foo {
  bar
}
@enduml
```

This example renders the following image:

[![Example - open link](http://www.plantuml.com/plantuml/svg/TOz1Qy9044Rl-oi-lMWXAF5M457GdhG1aLx3k3kn2xCxOR8fBQN_tVo17jyxF7ZxeP2LCOcRnUnb38njei8MIJQhUbM_hhscf7dd5hWfOkhL2iedO-Wj5aONXV6Z8uxD--A6p1nG5BsGPn1wuov-p_xFTog1hKtwnJldBeVshJaVJzVsqdoSbbSE5UeA8Le5OryeFuGhp0yGkhFCN_3h_fppGiE0JdL2u4usoJtdC8qz0G00 "Example")](http://www.plantuml.com/plantuml/uml/TOz1Qy9044Rl-oi-lMWXAF5M457GdhG1aLx3k3kn2xCxOR8fBQN_tVo17jyxF7ZxeP2LCOcRnUnb38njei8MIJQhUbM_hhscf7dd5hWfOkhL2iedO-Wj5aONXV6Z8uxD--A6p1nG5BsGPn1wuov-p_xFTog1hKtwnJldBeVshJaVJzVsqdoSbbSE5UeA8Le5OryeFuGhp0yGkhFCN_3h_fppGiE0JdL2u4usoJtdC8qz0G00)

### SVG sprites [material7, material7.4.47]

This library consists of a (SVG) Material Design Icons style icons from Google and other artists based on v7.4.47.
See the entire collection or search via a filter on the [Material Design Icons website](https://pictogrammers.com/library/mdi/).

The library can be included via `!include <material7/...>` or `!include <material7.4.47/...>`.
It is planned that `<material7/...>` is always the last 7.* version and therefore some sprites could be changed in the future.
If you want to ensure that your diagrams are not affected by these changes, you should use a specific version, e.g. `!include <material7.4.47/...>`.

The material design icons are organized in categories, e.g. `AccountUser`, `BrandLogo` etc.
The sprites can be included via their category and name, e.g. `!include <material7/AccountUser/AccountAlert>` or `all` of one category via `!include <material7/Emoji/all>`.
When imported, you can use the sprite as normally you would, using `<$mdiSpriteName>`.
Notice that this library requires an `mdi` prefix on sprites names, this is to avoid clash of names if multiple sprites have the same name on different libraries. `mdi` stands for Material Design Icon.

**Example of usage:**

```plantuml
@startuml
!include <material7/AccountUser/AccountAlert>
!include <material7/Emoji/all>

label "explicit loaded sprite in text\n<$mdiAccountAlert>" as accountAlertSprite
label "sprite loaded via category collection\nwith changed size and color\n<$mdiEmoticonLol{scale=0.75,color=red}>" as emoticonLol
@enduml
```

This example renders the following image:

[![material7 sprite example - open link](https://www.plantuml.com/plantuml/svg/TOunJq9H38NtzoigSJGF1ynRWC3WvcRSM6fl0pMzBRctLr7ZVrVm4NLmQvhlVEUiQc29bhMx42DjYM6UCRW8wj3F-jamNHDvitYeNCxtMhd4yl_8RVOdcQBgikiK7rbXmeUz2ac0EYPEKFT5Wa4CWW-niVbbJl97Fm6iWBy-zwV8MJWAHjsp8106Rxsy0hagKuZRnbuaTa0xjEsnLDuOqDAHy3AMVeqD8RSxr_TAgBouxeURgnEoA9m-lfVm3zQjs5BB-Wa0 "material7 sprite example")](https://www.plantuml.com/plantuml/uml/TOunJq9H38NtzoigSJGF1ynRWC3WvcRSM6fl0pMzBRctLr7ZVrVm4NLmQvhlVEUiQc29bhMx42DjYM6UCRW8wj3F-jamNHDvitYeNCxtMhd4yl_8RVOdcQBgikiK7rbXmeUz2ac0EYPEKFT5Wa4CWW-niVbbJl97Fm6iWBy-zwV8MJWAHjsp8106Rxsy0hagKuZRnbuaTa0xjEsnLDuOqDAHy3AMVeqD8RSxr_TAgBouxeURgnEoA9m-lfVm3zQjs5BB-Wa0)

**How to get all available sprite categories**

```plantuml
@startjson
!$material = %load_json('<material7/all.json>')
$material
@endjson
```

[![all sprite categories - open link](https://img.plantuml.biz/plantuml/svg/SoWkIImgoIhEp-FbKbJ9JIn9BSfCp56mLL3DoKzCYGT9QAZRmCJDzHDpSlH0WdRgchnSSFMyN0wfUIaWSG00)](https://editor.plantuml.com/uml/SoWkIImgoIhEp-FbKbJ9JIn9BSfCp56mLL3DoKzCYGT9QAZRmCJDzHDpSlH0WdRgchnSSFMyN0wfUIaWSG00)

**How to get all available sprite of a specific category**

```plantuml
@startuml
' To get all available sprites of a specific category, e.g. "all" of "material7.4.47/Emoji"
!include <material7/Emoji/all>
listsprites
@enduml
```

[![all Emoji sprites - open link](https://www.plantuml.com/plantuml/svg/ROqn2W8n44Nxd69COoFPPc4RaMsyWHSOixDXv6SZoKJmzYfORlbu3zxSZAlr37UaMw4aHWmGlrZ1TmYrPrMJHcKb_e94NJLIP9DKwlj44b8Wpu3_9JwpILN65COmJiCrbuTwTz0jeYz2vpq_C71nq6R_cPjbMth61m00)](https://www.plantuml.com/plantuml/uml/ROqn2W8n44Nxd69COoFPPc4RaMsyWHSOixDXv6SZoKJmzYfORlbu3zxSZAlr37UaMw4aHWmGlrZ1TmYrPrMJHcKb_e94NJLIP9DKwlj44b8Wpu3_9JwpILN65COmJiCrbuTwTz0jeYz2vpq_C71nq6R_cPjbMth61m00)

#### Macros and predefined values via `!include <material7/common>`

You may also include the `common.puml` file, e.g. `!include <material7/common>`, which contains helper macros, configurable default behaviors ...

With the `common.puml` imported, you can use following macros; note again the use of the prefix `$Mdi` and the image macro has the postfix `Img` too:

- `$MdiSpriteNameImg($sprite, $color = $MDI_DEFAULT, $scale = "1")`; e.g. **Mdi**EmoticonLol**Img**(...)
- `$MdiSpriteName($sprite, $alias, $label=$MDI_DEFAULT, $shape=$MDI_DEFAULT, $color=$MDI_DEFAULT, $scale=1, $stereo=$MDI_DEFAULT)`; e.g. **Mdi**EmoticonLol(...)

Following predefined values can be used as arguments too:

| Constant | Value | Description |
|----------|-------|-------------|
| `$MDI_LABEL_NONE` | `""` | No label |
| `$MDI_LABEL_ALIAS` | `"*"` | Use alias as label |
| `$MDI_SHAPE_NONE` | `"label"` | No visible shape |
| `$MDI_COLOR_NONE` | `""` | No color change |
| `$MDI_STEREOTYPE_NONE` | `""` | No stereotype |
| `$MDI_STEREOTYPE_SPRITE` | `"*"` | Use sprite name as stereotype |
| `$MDI_ALIGNMENT_NONE` | `""` | No alignment change |
| `$MDI_ALIGNMENT_LEFT` | `"left"` | Left alignment |
| `$MDI_ALIGNMENT_CENTER` | `"center"` | Center alignment |
| `$MDI_ALIGNMENT_RIGHT` | `"right"` | Right alignment |

The default values can be overwritten before the common.puml is included:

| Variable | Description | Default | Possible Values |
|----------|-------------|---------|----------------|
| `$MDI_ALIGNMENT` | Text alignment | `"center"` | `""` (none), `"left"`, `"center"`, `"right"` |
| `$MDI_DEFAULT_LABEL` | Default label behavior | `"*"` | `""` (no label), `"*"` (alias as label) |
| `$MDI_DEFAULT_SHAPE` | Default shape for elements | `"rectangle"` | `"label"` (no shape), `"rectangle"`, `"database"`, etc. |
| `$MDI_DEFAULT_COLOR` | Default icon color | `""` | `""` (no color), `"red"`, `"#FF0000"`, etc. |
| `$MDI_DEFAULT_STEREOTYPE` | Default stereotype | `""` | `""` (none), `"*"` (sprite name), custom text |

**Example of usage with `Mdi...Img` sprite calls:**

```plantuml
@startuml
!include <material7/common>
!include <material7/AccountUser/AccountAlert>

!$MDI_DEFAULT_COLOR = green

label "$MdiAccountAlertImg()\ndefault image color is changed to green" as defaultSprite
label "$MdiAccountAlertImg(red)" as redSprite
label "$MdiAccountAlertImg(red, 2.0)" as redLargeSprite
label "$MdiAccountAlertImg($color=blue)" as blueSprite
label "$MdiAccountAlertImg($scale=2.0)" as largeSprite
@enduml
```

[![Sprite-Image macro - open link](https://www.plantuml.com/plantuml/svg/ZSt1IiGm4CRnUvuYk_IW85LaOIzssM8L2Yq5jUSoJSOIc2GoITxVGh7qelRs7Vu_lck8m35P4WVZ52MDyib2H3P0v_oKdyxtoblhtUNte5JA9nVxWFopIqAE5o4EMLlLG_NoMlRDn_3SDTsRBEJ4Y4u8WX597hDMcoshxNHpUvGGfCPFI1JVlzX4_2jdr8kOnwxwJZxc3ojfW2VytsNAa-TYf8GBdTSU5XGG5kiXRTwkw7Ioz0q0)](https://www.plantuml.com/plantuml/uml/ZSt1IiGm4CRnUvuYk_IW85LaOIzssM8L2Yq5jUSoJSOIc2GoITxVGh7qelRs7Vu_lck8m35P4WVZ52MDyib2H3P0v_oKdyxtoblhtUNte5JA9nVxWFopIqAE5o4EMLlLG_NoMlRDn_3SDTsRBEJ4Y4u8WX597hDMcoshxNHpUvGGfCPFI1JVlzX4_2jdr8kOnwxwJZxc3ojfW2VytsNAa-TYf8GBdTSU5XGG5kiXRTwkw7Ioz0q0)

**Example of usage with `Mdi...` calls and different arguments:**

```plantuml
@startuml
!include <material7/common>
!include <material7/AccountUser/AccountAlert>

' Using default values (alias as label, rectangle shape)
$MdiAccountAlert(defaultAccount)

' Custom label
$MdiAccountAlert(labelAccount, "with changed $label")

' No label
$MdiAccountAlert(nolabelAccount, "")

' Alias as label
$MdiAccountAlert(aliaslabelAccount, $MDI_LABEL_ALIAS)

' Custom shape
$MdiAccountAlert(shapeDatabaseAccount, "with changed $label and $shape=database", $shape=database)

' No visible shape
$MdiAccountAlert(shapeNoneIsLabelAccount, "with changed $label and $shape=$MDI_SHAPE_NONE", $shape=$MDI_SHAPE_NONE)

' Custom color
$MdiAccountAlert(colorRedAccount, "with changed $label and $color=red", $color=red)

' Custom scale
$MdiAccountAlert(scaleSmallAccount, "with changed $label and $scale=0.5", $scale=0.5)
$MdiAccountAlert(scaleLargeAccount, "with changed $label and $scale=2.0", $scale=2.0)

' Custom stereotype
$MdiAccountAlert(stereotypeFixAccount, "with changed $label and $stereo=Abcd", $stereo=Abcd)
$MdiAccountAlert(stereotypeAliasAccount, "with changed $label and $stereo=$MDI_STEREOTYPE_SPRITE", $stereo=$MDI_STEREOTYPE_SPRITE)
@enduml
```

[![Sprite macro with different arguments - open link](https://www.plantuml.com/plantuml/svg/ZP9HQzim4CVV_Iaq4rWD9YkZeozBgRPwpE2w9KuVzXJEqYqHoDAGv6xxzlEk3dMQs1ZyuFlhxdVtr-dM1t2XRNJqJXcXMudiSmC1dG9zlRnQNbr_4BPfhBaPJ-12sDQ49u_kyCyrkd0JHU_ParTcnoJ-X5O7zWowHSykG2lmhFiqrAXJvb04C3kDpE_X5oRHubwg8UkY9_HQyX_zjVN1DY-8qmAIUoLbyMyLzapikoOesO8EOwAKTenWx1l6Im7lPnyh8s_7bOlxktnRy2zPiUL5pglX-6Jub4Bo7GIemUEa3GQc-wNybUmBulIjSl3whBogDKwsBQt1t1TaOMvdibXzvu_PjdmeipWTEHXQ5rPRTpe3oMkKCtfJwigXZDD1S7Iz0lGPdoHN3UWv3YbvTRdy5AU381cX5k1sE9lwSNbve59mD7j0XpRyFRUerxDlwi-SRfI_uhMWkng4oHIS7ljiVB_iJRRE7ZO_kerNZ-jyGuzXCY69Rj78jj7_0000)](https://www.plantuml.com/plantuml/uml/ZP9HQzim4CVV_Iaq4rWD9YkZeozBgRPwpE2w9KuVzXJEqYqHoDAGv6xxzlEk3dMQs1ZyuFlhxdVtr-dM1t2XRNJqJXcXMudiSmC1dG9zlRnQNbr_4BPfhBaPJ-12sDQ49u_kyCyrkd0JHU_ParTcnoJ-X5O7zWowHSykG2lmhFiqrAXJvb04C3kDpE_X5oRHubwg8UkY9_HQyX_zjVN1DY-8qmAIUoLbyMyLzapikoOesO8EOwAKTenWx1l6Im7lPnyh8s_7bOlxktnRy2zPiUL5pglX-6Jub4Bo7GIemUEa3GQc-wNybUmBulIjSl3whBogDKwsBQt1t1TaOMvdibXzvu_PjdmeipWTEHXQ5rPRTpe3oMkKCtfJwigXZDD1S7Iz0lGPdoHN3UWv3YbvTRdy5AU381cX5k1sE9lwSNbve59mD7j0XpRyFRUerxDlwi-SRfI_uhMWkng4oHIS7ljiVB_iJRRE7ZO_kerNZ-jyGuzXCY69Rj78jj7_0000)

**It can be combined with C4 stdlib too:**

```plantuml
@startuml
!include <C4/C4_Container>

' If common.puml is needed, disable alignment:
' !$MDI_ALIGNMENT = ""
' !include <material7/common>

!include <material7/AccountUser/AccountAlert>
!include <material7/Emoji/all>

Person(A, $sprite="mdiAccountAlert", $label="Person A")
Person(B, $sprite="mdiEmoticonNeutral", $label="Person B")

Rel(A, B, "Calls")
@enduml
```

[![Combined with C4 - open link](https://www.plantuml.com/plantuml/svg/TOtHIyCm48VV-rVSma25qRuK1cB7kZgau8g8Fe-iEILokOpa-lzxCeRAs5kuVD_tMsUnIQP0nSppI9D3UEZgggltNMIndZ6jYk86-WyOOmYHowF2u3CmeaEt0EUpFH229V_90Ldk5P_DTu_zldtkduRTTdY31epHy-z6i8B9MrgMTLalgrDRbwuIxJZ6YUKzOpg_My8ag-lADiGlNraYxRvWof5lsmNCyp5vmSO4v_-6Z7wHFI0rvWH3Q-xEtkQ_fsNnO-G19qcMBjMDgiKhqi-WkgQpH5blQsGt1Ve6)](https://www.plantuml.com/plantuml/uml/TOtHIyCm48VV-rVSma25qRuK1cB7kZgau8g8Fe-iEILokOpa-lzxCeRAs5kuVD_tMsUnIQP0nSppI9D3UEZgggltNMIndZ6jYk86-WyOOmYHowF2u3CmeaEt0EUpFH229V_90Ldk5P_DTu_zldtkduRTTdY31epHy-z6i8B9MrgMTLalgrDRbwuIxJZ6YUKzOpg_My8ag-lADiGlNraYxRvWof5lsmNCyp5vmSO4v_-6Z7wHFI0rvWH3Q-xEtkQ_fsNnO-G19qcMBjMDgiKhqi-WkgQpH5blQsGt1Ve6)


## Tupadr3 library [tupadr3]

This library contains several libraries of icons (including Devicons and Font Awesome).

Use it by including the file that contains the sprite, eg: `!include <tupadr3/font-awesome/align_center>`.
When imported, you can use the sprite as normally you would, using `<$sprite_name>`.

You may also include the `common.puml` file, eg: `!include <tupadr3/common>`, which contains helper macros defined.
With the `common.puml` imported, you can use the `NAME_OF_SPRITE(parameters...)` macro.

Example of usage:
```plantuml
@startuml
!include <tupadr3/common>
!include <tupadr3/font-awesome/server>
!include <tupadr3/font-awesome/database>

title Styling example

FA_SERVER(web1,web1) #Green
FA_SERVER(web2,web2) #Yellow
FA_SERVER(web3,web3) #Blue
FA_SERVER(web4,web4) #YellowGreen
FA_DATABASE(db1,LIVE,database,white) #RoyalBlue
FA_DATABASE(db2,SPARE,database) #Red

db1 <--> db2
web1 <--> db1
web2 <--> db1
web3 <--> db1
web4 <--> db1
@enduml
```

This example renders the following image:

![Example](http://www.plantuml.com/plantuml/png/XOvHIyCm58NVyolkyC49hMNjdcICTTZ9OC9eTU2JfCjr2wH9QMwj-_ScpbagWY-1mtU-axkmn1jgAyMkOQkufkV73LWIIfQWJGTIxrKhqC9wRtIuCfgWg1j9Q4TG8CAHgBPtKNIGT6pBsxsf8cfhBfeagjsSNmwbLz-S6jgpojZeUnTcbxOpAwFdVv0latTeJOMHnUOTctzhWXClkSKvOoH98HHqKb8V03zuLIjaR9M-5bc-o_9nX-KayCyDN3qqY7h8OizYnrvGATCDOU9Xuk1IjJX4Ku-cFzvvsLVkqwTqcHRPMBX_D-jT5bok3RgZ97HARavS-SbV_JWejcdU2xwAWZ6t1BCmd8EhCDPX7oS-nOEK3DAqJmlKegtK9m00 "Example")

## Sources

* **aws**: made by https://github.com/milo-minderbinder/AWS-PlantUML
* **classy**: made by https://github.com/james-gadrow-kr/classy-plantuml
* **classy-c4**: made by https://github.com/james-gadrow-kr/classy-c4
* **tupadr3**: made by https://github.com/tupadr3/plantuml-icon-font-sprites
* **Material Icons**: from https://github.com/Templarian/MaterialDesign
* **Bootstrap Icons**: from https://github.com/twbs/icons
* **Elastic Icons**: from https://github.com/Crashedmind/PlantUML-Elastic-icons
* **Domain Story**: from https://github.com/johthor/DomainStory-PlantUML

You can create Pull Request to update or add some library here if you find it relevant.
