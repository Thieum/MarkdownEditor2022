---
name: bootstrap1.12.1
display_name: Bootstrap
description: Bootstrap Icons from Bootstrap
author: The Bootstrap Authors
version: 1.12.1
release:
license: MIT License
source: https://github.com/twbs/icons
origin:
uid: b7e8070e077e207f0f213496d987646966999a98
---

Information about the `bootstrap1.12.1` Standard Library. The sprites are in one include file. See https://icons.getbootstrap.com/ for all icons names and prefix them with `bi-` to use them.
